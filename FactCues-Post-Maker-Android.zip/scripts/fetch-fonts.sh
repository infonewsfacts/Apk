#!/usr/bin/env bash
# Fonts ko app ke andar bundle karta hai (offline ke liye). Fail ho to build chalta rahega.
cd "$(dirname "$0")/.."
mkdir -p www/fonts
B="https://github.com/google/fonts/raw/main/ofl"
get() { curl -fsSL --retry 3 -o "www/fonts/$2" "$1" && echo "ok  $2" || { echo "WARN: $2 download nahi hua"; rm -f "www/fonts/$2"; }; }

get "$B/poppins/Poppins-Medium.ttf"    Poppins-Medium.ttf
get "$B/poppins/Poppins-Bold.ttf"      Poppins-Bold.ttf
get "$B/poppins/Poppins-ExtraBold.ttf" Poppins-ExtraBold.ttf
get "$B/poppins/Poppins-Black.ttf"     Poppins-Black.ttf
get "$B/notosansdevanagari/NotoSansDevanagari%5Bwdth%2Cwght%5D.ttf" NotoSansDevanagari.ttf

: > www/fonts.css
face() { # family weight file
  [ -f "www/fonts/$3" ] && printf '@font-face{font-family:"%s";font-weight:%s;font-style:normal;font-display:block;src:url("fonts/%s") format("truetype");}\n' "$1" "$2" "$3" >> www/fonts.css
}
face Poppins 500 Poppins-Medium.ttf
face Poppins 700 Poppins-Bold.ttf
face Poppins 800 Poppins-ExtraBold.ttf
face Poppins 900 Poppins-Black.ttf
face "Noto Sans Devanagari" "100 900" NotoSansDevanagari.ttf
echo "--- fonts.css ---"; cat www/fonts.css

#!/usr/bin/env bash
# `npx cap add android` ke baad chalta hai: icon, native save bridge, minSdk set karta hai.
set -e
cd "$(dirname "$0")/.."

cp -r native/res/. android/app/src/main/res/

JAVA_DIR=android/app/src/main/java/com/factcues/postmaker
mkdir -p "$JAVA_DIR"
cp native/java/*.java "$JAVA_DIR/"

# MediaStore (Pictures/FactCues) ke liye Android 10+ (API 29)
sed -i -E 's/minSdkVersion = [0-9]+/minSdkVersion = 29/' android/variables.gradle
grep minSdkVersion android/variables.gradle
echo "Android customization done."

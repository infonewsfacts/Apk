# FactCues Post Maker (Android)

Image + psychology fact se 4:5 post card banane wala app. Save karne par card gallery mein
`Pictures/FactCues` folder mein aata hai.

## APK kaise banayein (GitHub par)
1. GitHub par naya repository banayein (e.g. `factcues-post-maker`).
2. Is ZIP ki saari files (hidden `.github` folder samet) repo mein upload / push karein.
3. Repo mein **Actions** tab kholein → **Build APK** → agar khud start na ho to **Run workflow**.
4. ~5-8 minute baad run complete hone par neeche **Artifacts** mein `FactCues-Post-Maker-APK` download karein.
5. ZIP kholkar `app-debug.apk` phone mein install karein (Unknown sources allow karna padega).

## Notes
- Minimum Android version: 10 (API 29).
- Ye debug APK hai (personal use / testing ke liye). Play Store ke liye signed release build alag se banana hoga.
- Tool ka code `www/index.html` mein hai. Badalne ke baad push karein, APK dobara ban jayega.
- Icon `native/res/` mein hai; preview `icon-512.png`.
